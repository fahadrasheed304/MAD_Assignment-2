package com.example.mad_assignment02;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
